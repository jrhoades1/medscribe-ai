# MedScribe AI 🤖⚕️

AI-powered medical documentation that transforms patient consultations into structured clinical notes using Whisper + GPT-4.

![Next.js](https://img.shields.io/badge/Next.js-14-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue)
![Tailwind](https://img.shields.io/badge/Tailwind-3.4-38bdf8)

## Features

- 🎙️ **Audio Recording** - Record patient consultations directly in browser
- 🔄 **Speech-to-Text** - OpenAI Whisper for accurate medical transcription  
- 📝 **AI Clinical Notes** - GPT-4 generates structured SOAP notes
- 📋 **Copy & Export** - Easily copy notes or download as text

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **AI**: OpenAI Whisper (transcription), GPT-4 (note generation)
- **Backend**: Next.js API Routes
- **Database**: Supabase (optional, for auth/storage)
- **Deployment**: Vercel

## Getting Started

### 1. Clone & Install

```bash
git clone https://github.com/yourusername/medscribe-ai.git
cd medscribe-ai
npm install
```

### 2. Configure Environment

Copy `.env.example` to `.env.local` and add your API key:

```env
OPENAI_API_KEY=sk-your-openai-api-key
```

Get your OpenAI key from: https://platform.openai.com/api-keys

### 3. Run Locally

```bash
npm run dev
```

Open http://localhost:3000

### 4. Deploy to Vercel

```bash
npm i -g vercel
vercel
```

## Project Structure

```
medscribe-ai/
├── src/
│   ├── app/
│   │   ├── page.tsx           # Landing page
│   │   ├── dashboard/         # Main app
│   │   │   └── page.tsx
│   │   └── api/
│   │       ├── transcribe/    # Whisper API
│   │       └── generate-note/ # GPT-4 API
│   └── ...
├── supabase-schema.sql        # Database setup
└── README.md
```

## How It Works

1. **Record** - User clicks record and speaks their consultation
2. **Transcribe** - Audio is sent to Whisper API for transcription
3. **Generate** - Transcript is sent to GPT-4 with clinical prompt
4. **Output** - Structured SOAP note is displayed

## Cost Estimate

| Service | Usage | Cost |
|---------|-------|------|
| OpenAI Whisper | ~100 transcriptions/mo | ~$0.04/mo |
| OpenAI GPT-4 | ~100 note generations/mo | ~$5-10/mo |
| Vercel | Free tier | $0 |
| Supabase | Free tier | $0 |
| **Total** | | **~$5-10/mo** |

## Future Enhancements

- [ ] Multi-speaker identification
- [ ] Real-time transcription
- [ ] EHR integration (Epic, Cerner)
- [ ] Voice commands
- [ ] Medical coding (ICD-10, CPT)

## License

MIT

---

Built with ❤️ for healthcare
