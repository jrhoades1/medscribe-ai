import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const SYSTEM_PROMPT = `You are a medical scribe AI. Given a transcript of a patient consultation, generate a structured SOAP note.

Output ONLY JSON in this exact format:
{
  "subjective": "Patient's chief complaint and history",
  "objective": "Vital signs and examination findings",
  "assessment": "Diagnosis or differential diagnoses",
  "plan": "Treatment plan and next steps"
}

Be concise, clinically accurate, and use proper medical terminology.`

export async function POST(request: NextRequest) {
  try {
    const { transcript } = await request.json()

    if (!transcript) {
      return NextResponse.json({ error: 'No transcript provided' }, { status: 400 })
    }

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: `Generate a clinical note from this transcript:\n\n${transcript}` },
      ],
      response_format: { type: 'json_object' },
    })

    const clinicalNote = JSON.parse(completion.choices[0].message.content || '{}')

    return NextResponse.json({ clinicalNote })
  } catch (error) {
    console.error('Note generation error:', error)
    return NextResponse.json({ error: 'Failed to generate note' }, { status: 500 })
  }
}
