import Link from 'next/link'
import { Mic, FileText, Zap, Github } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-700">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Mic className="w-8 h-8 text-cyan-400" />
            <span className="text-2xl font-bold text-white">MedScribe</span>
            <span className="text-cyan-400 font-light">AI</span>
          </div>
          <a 
            href="https://github.com/yourusername/medscribe-ai"
            target="_blank"
            className="flex items-center space-x-2 text-slate-300 hover:text-white transition"
          >
            <Github className="w-5 h-5" />
            <span>GitHub</span>
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Turn Consultations into
            <span className="text-cyan-400"> Clinical Notes</span>
          </h1>
          <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
            AI-powered medical documentation that captures patient consultations 
            and generates structured SOAP notes in seconds.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/dashboard"
              className="bg-cyan-500 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-cyan-400 transition flex items-center justify-center"
            >
              Start Recording
            </Link>
            <a 
              href="https://github.com/yourusername/medscribe-ai"
              target="_blank"
              className="border border-slate-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-slate-700 transition"
            >
              View Source
            </a>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6 bg-slate-800/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-16">
            Built with Modern Tech
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
              <Mic className="w-10 h-10 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Whisper Speech-to-Text</h3>
              <p className="text-slate-400">
                OpenAI's Whisper API provides best-in-class medical transcription accuracy.
              </p>
            </div>
            <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
              <FileText className="w-10 h-10 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">GPT-4 Clinical Notes</h3>
              <p className="text-slate-400">
                Generate structured SOAP notes automatically from consultation transcripts.
              </p>
            </div>
            <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
              <Zap className="w-10 h-10 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Next.js + Supabase</h3>
              <p className="text-slate-400">
                Modern full-stack architecture with real-time database and authentication.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-8">Tech Stack</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {['Next.js 14', 'React', 'TypeScript', 'Tailwind CSS', 'OpenAI Whisper', 'GPT-4', 'Supabase', 'Vercel'].map(tech => (
              <span key={tech} className="bg-slate-700 text-slate-200 px-4 py-2 rounded-full">
                {tech}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-slate-700">
        <div className="max-w-6xl mx-auto text-center text-slate-500">
          <p>MedScribe AI - Open Source Medical Documentation</p>
        </div>
      </footer>
    </div>
  )
}
