'use client'

import { useState, useRef } from 'react'
import { Mic, Square, Copy, Download, Loader2 } from 'lucide-react'

interface ClinicalNote {
  subjective: string
  objective: string
  assessment: string
  plan: string
}

export default function Dashboard() {
  const [recording, setRecording] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [transcript, setTranscript] = useState<string | null>(null)
  const [clinicalNote, setClinicalNote] = useState<ClinicalNote | null>(null)
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<'record' | 'transcribe' | 'generate' | 'done'>('record')
  
  const mediaRecorder = useRef<MediaRecorder | null>(null)
  const audioChunks = useRef<Blob[]>([])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      mediaRecorder.current = new MediaRecorder(stream)
      audioChunks.current = []

      mediaRecorder.current.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunks.current.push(e.data)
        }
      }

      mediaRecorder.current.onstop = () => {
        const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' })
        const url = URL.createObjectURL(audioBlob)
        setAudioUrl(url)
        setStep('transcribe')
      }

      mediaRecorder.current.start()
      setRecording(true)
    } catch (err) {
      console.error('Error accessing microphone:', err)
      alert('Could not access microphone. Please grant permission.')
    }
  }

  const stopRecording = () => {
    if (mediaRecorder.current) {
      mediaRecorder.current.stop()
      setRecording(false)
    }
  }

  const processAudio = async () => {
    if (!audioUrl) return
    
    setLoading(true)
    
    try {
      // Step 1: Get audio file from URL
      const audioBlob = await fetch(audioUrl).then(r => r.blob())
      
      // Step 2: Transcribe via API
      const transcribeRes = await fetch('/api/transcribe', {
        method: 'POST',
        body: audioBlob,
      })
      const { transcript: transcriptText } = await transcribeRes.json()
      setTranscript(transcriptText)
      setStep('generate')
      
      // Step 3: Generate clinical note
      const noteRes = await fetch('/api/generate-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: transcriptText }),
      })
      const { clinicalNote: note } = await noteRes.json()
      setClinicalNote(note)
      setStep('done')
    } catch (err) {
      console.error('Processing error:', err)
      alert('Error processing audio. Check console for details.')
    } finally {
      setLoading(false)
    }
  }

  const copyNote = () => {
    if (!clinicalNote) return
    const text = `SUBJECTIVE: ${clinicalNote.subjective}\n\nOBJECTIVE: ${clinicalNote.objective}\n\nASSESSMENT: ${clinicalNote.assessment}\n\nPLAN: ${clinicalNote.plan}`
    navigator.clipboard.writeText(text)
    alert('Copied to clipboard!')
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">MedScribe AI</h1>
        
        {/* Step 1: Recording */}
        {step === 'record' && (
          <div className="bg-slate-800 rounded-xl p-12 text-center">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-cyan-500/20 flex items-center justify-center">
              <Mic className={`w-12 h-12 ${recording ? 'text-red-500' : 'text-cyan-400'}`} />
            </div>
            <h2 className="text-2xl font-semibold mb-4">
              {recording ? 'Recording...' : 'Start Your Consultation'}
            </h2>
            <p className="text-slate-400 mb-8">
              Click below to start recording your patient consultation.
            </p>
            {!recording ? (
              <button
                onClick={startRecording}
                className="bg-cyan-500 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-cyan-400 transition"
              >
                Start Recording
              </button>
            ) : (
              <button
                onClick={stopRecording}
                className="bg-red-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-red-600 transition flex items-center gap-2 mx-auto"
              >
                <Square className="w-5 h-5" /> Stop Recording
              </button>
            )}
          </div>
        )}

        {/* Step 2: Transcribing */}
        {step === 'transcribe' && audioUrl && (
          <div className="bg-slate-800 rounded-xl p-12 text-center">
            <audio src={audioUrl} controls className="w-full mb-8" />
            <p className="text-slate-400 mb-8">Preview your recording, then process it.</p>
            <button
              onClick={processAudio}
              disabled={loading}
              className="bg-cyan-500 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-cyan-400 transition disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'Generate Clinical Note'}
            </button>
          </div>
        )}

        {/* Step 3-4: Results */}
        {(step === 'generate' || step === 'done') && clinicalNote && (
          <div className="space-y-6">
            <div className="bg-slate-800 rounded-xl p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Clinical Note</h2>
                <div className="flex gap-2">
                  <button onClick={copyNote} className="flex items-center gap-2 text-slate-300 hover:text-white">
                    <Copy className="w-4 h-4" /> Copy
                  </button>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-cyan-400 font-semibold mb-2">Subjective</h3>
                  <p className="text-slate-300 whitespace-pre-line">{clinicalNote.subjective}</p>
                </div>
                <div>
                  <h3 className="text-cyan-400 font-semibold mb-2">Objective</h3>
                  <p className="text-slate-300 whitespace-pre-line">{clinicalNote.objective}</p>
                </div>
                <div>
                  <h3 className="text-cyan-400 font-semibold mb-2">Assessment</h3>
                  <p className="text-slate-300 whitespace-pre-line">{clinicalNote.assessment}</p>
                </div>
                <div>
                  <h3 className="text-cyan-400 font-semibold mb-2">Plan</h3>
                  <p className="text-slate-300 whitespace-pre-line">{clinicalNote.plan}</p>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => {
                setStep('record')
                setAudioUrl(null)
                setTranscript(null)
                setClinicalNote(null)
              }}
              className="text-cyan-400 hover:text-cyan-300"
            >
              ← Start New Consultation
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
